# WhatsappprojectupGit
 A MERN stack realtime chatting website with socket io
