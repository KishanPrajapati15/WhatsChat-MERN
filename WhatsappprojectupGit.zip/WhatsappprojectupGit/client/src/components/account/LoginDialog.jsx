import { useContext } from 'react';

import { Dialog, Typography, List, ListItem, Box, styled } from '@mui/material';

import { GoogleLogin } from '@react-oauth/google';
import jwt_decode from "jwt-decode";

import { addUser } from '../../service/api';
import { AccountContext } from '../../context/AccountProvider';


const Component = styled(Box)`
    display: 'flex';
`;
const Title = styled(Typography)`
    font-size: 20px; 
    font-family: inherit;
    font-weight: bold;
    text-align: 'centre';
    align-items: 'centre'; 
    padding-left: 10%;
`;

const Container = styled(Box)`
    padding: 56px 0px 0px 56px;
    text-align: 'centre';
    margin-bottom: 15px;
    
    
`;

//for dialog css
const dialogStyle = {
    boxShadow: 'none',
    overflow: 'hidden',
    
}



const LoginDialog = () => {

    const { setAccount,showloginButton, setShowloginButton, setShowlogoutButton } = useContext(AccountContext);

    const onLoginSuccess = async (res) => {
        let decoded = jwt_decode(res.credential);
        setAccount(decoded);
        setShowloginButton(false);
        setShowlogoutButton(true);
        await addUser(decoded);
    };

    const onLoginFailure = (res) => {
        console.log('Login Failed:', res);
    };

    // const onSignoutSuccess = () => {
    //     alert("You have been logged out successfully");
    //     console.clear();
    //     setShowloginButton(true);
    //     setShowlogoutButton(false);
    // };

    return (
        <Dialog
            open={true}
            BackdropProps={{style: {backgroundColor: 'unset'}}}
            maxWidth={'md'}
            PaperProps={{ sx: dialogStyle }}
        >
            <Component>
                <Container>
                    <Title>Sigin to use App</Title>
                </Container>
                <Box>
                    <Box>
                        { showloginButton ?
                            <GoogleLogin
                                buttonText=""
                                onSuccess={onLoginSuccess}
                                onError={onLoginFailure}
                            /> : null}
                    </Box>
                </Box>
            </Component>
        </Dialog>
    )
}

export default LoginDialog;